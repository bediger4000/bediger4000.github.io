-- $Id: create_batch_tables.sql,v 1.2 2012/06/29 15:12:12 bediger Exp $
CREATE TABLE batch (
	batch_no serial UNIQUE PRIMARY KEY,
	batch_dt timestamp WITH TIME ZONE NOT NULL,
	load_type VARCHAR(32) NOT NULL, -- access_log, p0f, 404scanner, etc
	rows_inserted_cnt integer,  -- number of rows inserted by this load
	note     VARCHAR(2048)
);

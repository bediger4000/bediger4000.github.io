-- $Id: create_p0f_tables.sql,v 1.2 2012/07/03 13:36:50 bediger Exp $

CREATE TABLE os_guess_d (
	os_guess_id   serial unique primary key,
	os_guess      VARCHAR(2048)
);
create index os_guess_d_idx1 on os_guess_d (os_guess);

CREATE TABLE link_d (
	link_id       serial unique primary key,
	link          VARCHAR(2048)
);
create index link_d_idx1 on link_d (link);

CREATE TABLE note_d (
	note_id       serial unique primary key,
	note          VARCHAR(2048)
);
create index note_d_idx1 on note_d (note);

CREATE TABLE p0f (
	p0f_no serial unique primary key,
	tstmp         timestamp with time zone,
	from_addr     inet,
	from_port     integer,
	to_addr       inet,
	to_port       integer,
	distance      integer,
	uptime        integer,
	nat_flag      varchar(1),
	fw_flag       varchar(1),
	os_guess_id   integer REFERENCES os_guess_d MATCH FULL,
	link_id       integer REFERENCES link_d MATCH FULL,
	notes_id      integer REFERENCES note_d MATCH FULL,
	seq_no        integer REFERENCES access_log MATCH FULL,
		-- the access_log row that probably matches this scan
	batch_no      integer REFERENCES batch MATCH FULL
);
create index p0f_idx1 on p0f (tstmp);
create index p0f_idx2 on p0f (from_addr);
create index p0f_idx3 on p0f (from_port);
create index p0f_idx4 on p0f (seq_no);

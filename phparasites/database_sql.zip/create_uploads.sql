create table uploads (
    uploads_id serial unique primary key,
	unique_id VARCHAR(24),
	parent_filename VARCHAR(52),
	upload_filename VARCHAR(128),
	from_addr inet,
	file_format VARCHAR(100)
);

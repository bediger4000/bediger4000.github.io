-- $Id: create_access_log_tables.sql,v 1.3 2013/11/08 04:00:32 bediger Exp $

CREATE TABLE host_data_d (
	host_data_id serial unique primary key,
	host_data VARCHAR(128)
);
create index host_data_d_idx1 on host_data_d (host_data);

CREATE TABLE query_data_d (
	query_data_id serial unique primary key,
	query_data VARCHAR(1024) -- "q=" part of a google or bing referral, "p" part of yahoo referral
);

CREATE TABLE referer_d (
	referer_id serial unique primary key,
	referer      VARCHAR(2048),
	query_data_id integer -- if the "host" part of referer is a bing or google hostname
		REFERENCES query_data_d,
	host_data_id integer -- host name in the referer field.
		REFERENCES host_data_d
);
create index referer_d_idx1 on referer_d (referer);
create index referer_d_idx2 on referer_d (query_data_id);
create index referer_d_idx3 on referer_d (host_data_id);


CREATE TABLE user_agent_d (
	user_agent_id serial unique primary key,
	user_agent   VARCHAR(2048),
	os           VARCHAR(64),  -- 'MAC', 'LINUX', 'WINDOWS', 'SOLARIS', 'OTHER'
	browser      VARCHAR(64)   -- 'IE', 'FIREFOX', 'MOZILLA', 'OPERA', 'SAFARI', 'DILLO', etc
);
create index user_agent_d_idx1 on user_agent_d (user_agent);
create index user_agent_d_idx2 on user_agent_d (os);
create index user_agent_d_idx3 on user_agent_d (browser);

CREATE TABLE http_uri_d (
	http_uri_id  serial unique primary key,
	http_uri     VARCHAR(2200),
	category     VARCHAR(32)
);
create index http_uri_d_idx1 on http_uri_d (http_uri);

CREATE TABLE http_method_d (
	http_method_id serial unique primary key,
	http_method  VARCHAR(256)

);
create index http_method_d_idx1 on http_method_d (http_method);

CREATE TABLE http_version_d (
	http_version_id serial unique primary key,
	http_version VARCHAR(15)
);

CREATE TABLE keyword_d (
	keyword_id serial unique primary key,
	keyword VARCHAR(128)
);


CREATE TABLE query_keyword_match (
	query_keyword_match_id serial unique primary key,
	referer_id integer REFERENCES referer_d MATCH FULL,
	keyword_id integer REFERENCES keyword_d MATCH FULL
);
create index query_keyword_match_idx1 on query_keyword_match (referer_id);
create index query_keyword_match_idx2 on query_keyword_match (keyword_id);

CREATE TABLE access_log (
	seq_no serial unique primary key,
	ip_addr      inet NOT NULL,
	request_dt   timestamp with time zone NOT NULL,
	http_method_id integer REFERENCES http_method_d MATCH FULL,
	http_version_id integer REFERENCES http_version_d MATCH FULL,
	http_uri_id  integer REFERENCES http_uri_d MATCH FULL,
	resp_cd      integer NOT NULL,
	bytes_sent   integer,
	referer_id     integer REFERENCES referer_d MATCH FULL,
	user_agent_id  integer REFERENCES user_agent_d MATCH FULL,
	batch_no     integer NOT NULL REFERENCES batch MATCH FULL
);

create index access_log_idx_1 on access_log (ip_addr);
create index access_log_idx_2 on access_log (request_dt);

INSERT INTO http_method_d (http_method) VALUES ('GET');
INSERT INTO http_method_d (http_method) VALUES ('POST');
INSERT INTO http_method_d (http_method) VALUES ('PUT');
INSERT INTO http_method_d (http_method) VALUES ('OPTIONS');
INSERT INTO http_method_d (http_method) VALUES ('HEAD');
INSERT INTO http_method_d (http_method) VALUES ('CONNECT');

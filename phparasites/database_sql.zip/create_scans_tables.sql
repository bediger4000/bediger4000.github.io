-- $Id: create_scans_tables.sql,v 1.9 2013/12/31 21:08:03 bediger Exp $

CREATE TABLE env_name_d (
	env_name_id serial unique primary key,
	env_name VARCHAR(256)
);
create index env_name_idx1 on env_name_d (env_name);

CREATE TABLE env_value_d (
	env_value_id serial unique primary key,
	env_value VARCHAR(512)
);
create index env_value_idx1 on env_value_d (env_value);

CREATE TABLE req_name_d (
	req_name_id serial unique primary key,
	req_name VARCHAR(256)
);
create index req_name_idx1 on req_name_d (req_name);

CREATE TABLE req_value_d (
	req_value_id serial unique primary key,
	req_value VARCHAR(512)
);
create index req_value_idx1 on req_value_d (req_value);

CREATE TABLE cookie_name_d (
	cookie_name_id serial unique primary key,
	cookie_name VARCHAR(256)
);
create index cookie_name_idx1 on cookie_name_d (cookie_name);

CREATE TABLE cookie_value_d (
	cookie_value_id serial unique primary key,
	cookie_value VARCHAR(512)
);
create index cookie_value_idx1 on cookie_value_d (cookie_value);

-- From nmap data
CREATE TABLE port_d (
	port_id serial unique primary key,
	port_data VARCHAR(128),
	port_status VARCHAR(10)
);

-- Unifies the _Server values and the nmap ports list and OS guess value(s).
CREATE TABLE scan (
	scan_id serial unique primary key,
	tstmp         timestamp with time zone NOT NULL,  -- should match access_log.request_dt
	from_addr     inet NOT NULL,                      -- should match access_log.ip_addr
	from_port     integer NOT NULL,
	http_uri_id   integer NOT NULL REFERENCES http_uri_d MATCH FULL,
		-- should match access_log.http_uri_id, from $_Server[SCRIPT_URL]
	user_agent_id integer REFERENCES user_agent_d MATCH FULL,
		-- from $_Server[USER_AGENT], not always present.
	from_fqdn     VARCHAR(256),  -- if nmap found one.
	os_guess_id integer REFERENCES os_guess_d MATCH FULL, -- "^Running: ", not a guess
	os_details_id integer REFERENCES os_guess_d MATCH FULL, -- "Details:" line
	seq_no integer, -- access_log.seq_no, but maybe doesn't always match?
	filename     VARCHAR(1024),
	unique_id VARCHAR(30),
	batch_no integer NOT NULL REFERENCES batch MATCH FULL
);
create index scan_idx1 on scan (tstmp);
create index scan_idx2 on scan (from_addr);
create index scan_idx3 on scan (from_port);

-- maps scan_id to nmap_port_id and back.
CREATE TABLE nmap_ports_list (
	nmap_ports_list_id serial unique primary key,
	nmap_port_id integer REFERENCES port_d MATCH FULL,
	scan_id integer REFERENCES scan MATCH FULL
);

CREATE TABLE nmap_os_guess_list (
	nmap_os_guess_list_id  serial unique primary key,
	confidence integer,
	scan_id integer REFERENCES scan MATCH FULL,
	os_guess_id integer REFERENCES os_guess_d MATCH FULL
);

CREATE TABLE nmap_aggressive_guess_list (
	nmap_aggressive_guess_list_id  serial unique primary key,
	confidence integer,
	scan_id integer REFERENCES scan MATCH FULL,
	os_guess_id integer REFERENCES os_guess_d MATCH FULL
);

CREATE TABLE env_link (
	env_link_id serial unique primary key,
	env_value_id integer REFERENCES env_value_d MATCH FULL,
	env_name_id  integer REFERENCES env_name_d  MATCH FULL,
	scan_id      integer REFERENCES scan        MATCH FULL
);
create index env_link_idx1 on env_link (env_value_id);
create index env_link_idx2 on env_link (env_name_id);

CREATE TABLE req_link (
	req_link_id serial unique primary key,
	req_value_id integer REFERENCES req_value_d MATCH FULL,
	req_name_id  integer REFERENCES req_name_d  MATCH FULL,
	scan_id      integer REFERENCES scan        MATCH FULL
);
create index req_link_idx1 on req_link (req_value_id);
create index req_link_idx2 on req_link (req_name_id);

CREATE TABLE cookie_link (
	cookie_link_id serial unique primary key,
	cookie_value_id integer REFERENCES cookie_value_d MATCH FULL,
	cookie_name_id  integer REFERENCES cookie_name_d  MATCH FULL,
	scan_id      integer REFERENCES scan        MATCH FULL
);
create index cookie_link_idx1 on cookie_link (cookie_value_id);
create index cookie_link_idx2 on cookie_link (cookie_name_id);

CREATE TABLE uploaded_files (
	uploaded_file_id serial unique primary key,
	scan_id integer REFERENCES scan MATCH FULL,
	name    VARCHAR(128),
	type    VARCHAR(128),
	size    VARCHAR(128)
);
create index uploaded_files_idx1 on uploaded_files (uploaded_file_id);
create index uploaded_files_idx2 on uploaded_files (scan_id);
